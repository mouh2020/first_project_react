import React from 'react'

function Formulaire() {
  return (
    <div>Formulaire</div>
  )
}

export default Formulaire