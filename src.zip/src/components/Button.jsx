import React from 'react'

function Button() {
  return (
    <div>
        <button type="submit">Send</button>
    </div>
  )
}

export default Button