import React from 'react'

function ProductDetails() {
  return (
    <div>ProductDetails</div>
  )
}

export default ProductDetails