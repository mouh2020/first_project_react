import React from 'react'

function Input() {
  return (
    <div>
        <input></input>
    </div>
  )
}

export default Input