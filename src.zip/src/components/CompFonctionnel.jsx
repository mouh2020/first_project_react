import React from 'react'

function CompFonctionnel() {
  return (
    <div>
        <h1>Mon premier composant react</h1>
    </div>
  )
}

export default CompFonctionnel