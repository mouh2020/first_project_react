import React, { Component } from 'react'

export default class CompClasse extends Component {
  render() {
    return (
      <div>CompClasse</div>
    )
  }
}
