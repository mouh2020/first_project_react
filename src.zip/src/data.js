const data = [
      {
        id: 1,
    name: "HP-Victus",
        title: "G-35943-1-HP-Victus-Gaming-15",
        price: "1466€",
        image: "/pictures/pc1.jpg",
      },
      {
        id: 2,
    name: "HP-Victus",
        title: "G-37526-1-pc-portable-gaming-hp-victus-16",
        price: "1227 €",
        image: "/pictures/pc2.jpeg",
      },
      {
        id: 3,
    name: " asus ",
        title: "G-37932-1-asus-vivobook-pro-15",
        price: "1466€",
        image: "/pictures/pc3.jpg",
      },
      {
        id: 4,
    name: " Lenovo ",
        title: "G-38002-1-Lenovo-LOQ",
        price: "1299€",
        image: "/pictures/pc4.jpg",
      },
    
      {
        id: 5,
    name: " THOMSON",
        title: "PC Portable Notebook - THOMSON",
        price: "1460€",
        image: "/pictures/pc5.jpg",
      },
      {
        id: 6,
    name: "HP-Victus",
        title: "PC Portable Gamer HP Victus 16",
        price: "1300€",
        image: "/pictures/pc6.jpg",
      },
      {
        id: 7,
    name: "HP-Victus",
    
        title: "Le PC portable gamer Lenovo ",
        price: "1400€",
        image: "/pictures/pc7.jpg",
      },
    ];
    export default data;
    
    